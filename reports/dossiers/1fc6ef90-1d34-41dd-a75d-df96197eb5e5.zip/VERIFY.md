# Forensic Verification Instructions

Verify this dossier bundle with:
```bash
uv run vigil-verify bundle.zip --pubkey pubkey.pem
```
